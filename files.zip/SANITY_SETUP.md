# Sanity CMS Integration Guide for GeorgiaUSA

## Overview
This guide will help you set up Sanity CMS for managing vacancies and news content on your GeorgiaUSA website.

## Step 1: Install Dependencies

Run the following command in your project root:

```bash
npm install @sanity/client @sanity/image-url sanity @sanity/vision styled-components
```

## Step 2: Create Sanity Project

1. **Sign up for Sanity** (if you haven't already):
   - Go to https://www.sanity.io/
   - Click "Get started" and create a free account

2. **Initialize Sanity in your project**:
   ```bash
   npm install -g @sanity/cli
   sanity init
   ```

3. **During initialization**:
   - Choose "Create new project"
   - Give it a name (e.g., "GeorgiaUSA")
   - Choose "Production" dataset
   - Select "Clean project with no predefined schemas"
   - The CLI will give you a **PROJECT ID** - save this!

## Step 3: Configure Environment Variables

1. Create a `.env` file in your project root:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` and add your Sanity project ID:
   ```
   VITE_SANITY_PROJECT_ID=your_actual_project_id_here
   VITE_SANITY_DATASET=production
   ```

## Step 4: Update sanity.config.ts

Replace `YOUR_PROJECT_ID` in `sanity.config.ts` with your actual project ID.

## Step 5: Start Sanity Studio

Run the Sanity Studio (admin panel) locally:

```bash
npm run sanity
```

This will start Sanity Studio at http://localhost:3333

## Step 6: Deploy Sanity Studio (Optional but Recommended)

Deploy your Sanity Studio so you can manage content from anywhere:

```bash
npm run sanity:deploy
```

This will give you a URL like: https://your-project-name.sanity.studio

## Step 7: Add Content

1. Open Sanity Studio (locally or deployed)
2. You'll see two content types:
   - **Vacancies**: For job postings
   - **News**: For news articles

### Adding a Vacancy:
1. Click "Vacancies" in the sidebar
2. Click "Create new vacancy"
3. Fill in:
   - Job Title
   - Generate slug (click "Generate")
   - Location
   - Salary (optional)
   - Employment Type
   - Description (rich text editor)
   - Requirements (rich text editor)
   - Benefits (list)
   - Published date
   - Deadline (optional)
   - Is Active checkbox
4. Click "Publish"

### Adding News:
1. Click "News" in the sidebar
2. Click "Create new news"
3. Fill in:
   - Title
   - Generate slug
   - Author
   - Main Image (upload)
   - Excerpt (short summary)
   - Content (rich text with images)
   - Category
   - Tags
   - Published date
   - Featured checkbox
4. Click "Publish"

## Step 8: Use Content in Your React App

The project includes ready-to-use hooks:

### Display Vacancies:
```typescript
import { useVacancies } from '@/hooks/useVacancies'

function VacanciesPage() {
  const { data: vacancies, isLoading } = useVacancies()
  
  if (isLoading) return <div>Loading...</div>
  
  return (
    <div>
      {vacancies?.map((vacancy) => (
        <div key={vacancy._id}>
          <h2>{vacancy.title}</h2>
          <p>{vacancy.location}</p>
          <p>{vacancy.salary}</p>
        </div>
      ))}
    </div>
  )
}
```

### Display News:
```typescript
import { useNews } from '@/hooks/useNews'
import { urlFor } from '@/lib/sanity'

function NewsPage() {
  const { data: news, isLoading } = useNews()
  
  if (isLoading) return <div>Loading...</div>
  
  return (
    <div>
      {news?.map((article) => (
        <div key={article._id}>
          {article.mainImage && (
            <img 
              src={urlFor(article.mainImage).width(400).url()} 
              alt={article.mainImage.alt}
            />
          )}
          <h2>{article.title}</h2>
          <p>{article.excerpt}</p>
          <small>By {article.author}</small>
        </div>
      ))}
    </div>
  )
}
```

## File Structure

```
your-project/
├── sanity/
│   └── schemas/
│       ├── index.ts       # Export all schemas
│       ├── vacancy.ts     # Vacancy schema
│       └── news.ts        # News schema
├── src/
│   ├── hooks/
│   │   ├── useVacancies.ts  # Vacancy hooks
│   │   └── useNews.ts       # News hooks
│   ├── lib/
│   │   └── sanity.ts        # Sanity client config
│   └── types/
│       └── sanity.ts        # TypeScript types
├── sanity.config.ts         # Sanity configuration
├── .env                     # Environment variables
└── package.json
```

## Available Hooks

### Vacancies:
- `useVacancies()` - Get all active vacancies
- `useVacancy(slug)` - Get single vacancy by slug

### News:
- `useNews()` - Get all news articles
- `useNewsArticle(slug)` - Get single news article by slug
- `useFeaturedNews()` - Get featured news articles (max 3)

## Content Management

### To Update Content:
1. Go to your Sanity Studio
2. Find the document you want to edit
3. Make changes
4. Click "Publish"
5. Changes appear in your website immediately (with CDN cache)

### To Delete Content:
- Set `isActive` to `false` for vacancies (recommended)
- Or click the three dots → "Delete" (permanent)

## CORS Configuration

If you get CORS errors:
1. Go to https://www.sanity.io/manage
2. Select your project
3. Go to "API" → "CORS Origins"
4. Add your Netlify URL (e.g., `https://your-site.netlify.app`)
5. Add `http://localhost:8080` for local development

## Useful Queries

### Get only active vacancies:
```typescript
const query = `*[_type == "vacancy" && isActive == true]`
```

### Get news by category:
```typescript
const query = `*[_type == "news" && category == "events"]`
```

### Search vacancies:
```typescript
const query = `*[_type == "vacancy" && title match "*engineer*"]`
```

## Support

- Sanity Documentation: https://www.sanity.io/docs
- Sanity Community: https://www.sanity.io/community

## What You Get

✅ **Easy Content Management**: Non-technical users can add/edit content
✅ **Real-time Updates**: Content changes appear immediately
✅ **Rich Text Editing**: Beautiful editor for descriptions
✅ **Image Handling**: Upload and optimize images automatically
✅ **TypeScript Support**: Full type safety
✅ **Free Tier**: Generous free tier (perfect for your use case)
- 3 users
- 10GB bandwidth/month
- Unlimited documents
- Unlimited API requests

## Next Steps

1. Install dependencies: `npm install`
2. Create Sanity project: `sanity init`
3. Add your project ID to `.env`
4. Start Sanity Studio: `npm run sanity`
5. Add some test content
6. Deploy Sanity Studio: `npm run sanity:deploy`
7. Use the provided hooks in your React components
